from prepare_data import prepare_image
from keras.models import model_from_json
import numpy as np
import os
import pandas as pd


dirr=r'predict'
weights_path=r'model\model.h5'


json_file = open(r'architecture\model_architecture.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
model = model_from_json(loaded_model_json)
model.load_weights(weights_path)
print("Model Loaded")

labels =pd.read_csv('labels.csv')
for i in os.listdir(dirr):
    predictions = model.predict(prepare_image(os.path.join(dirr,i)))
    print(i,labels.at[np.argmax(predictions),'classes'])

