import pandas as pd
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ModelCheckpoint
from keras.models import Model
from keras.layers import Dense,GlobalAveragePooling2D
from keras.applications import MobileNet
from keras.applications.mobilenet import preprocess_input
import warnings
warnings.filterwarnings("ignore")


# HyperParameter
epochs=20
img_path = r'test'
period=1


base_model=MobileNet(weights=r'pretrained\mobilenet_1_0_224_tf_no_top.h5',include_top=False) #imports the mobilenet model and discards the last 1000 neuron layer.
x=base_model.output
x=GlobalAveragePooling2D()(x)
x=Dense(1024,activation='relu')(x) #we add dense layers so that the model can learn more complex functions and classify for better results.
x=Dense(1024,activation='relu')(x) #dense layer 2
x=Dense(512,activation='relu')(x) #dense layer 3
preds=Dense(5,activation='softmax',)(x) #final layer with softmax activation
model=Model(inputs=base_model.input,outputs=preds)

for layer in model.layers:
  layer.trainable = False
# or if we want to set the first 20 layers of the network to be non-trainable
for layer in model.layers[:20]:
  layer.trainable = False
for layer in model.layers[20:]:
  layer.trainable = True

train_datagen=ImageDataGenerator(preprocessing_function=preprocess_input) #included in our dependencies
train_generator=train_datagen.flow_from_directory(img_path,
                                                 target_size=(600,400),
                                                 color_mode='rgb',
                                                 batch_size=4,
                                                 class_mode='categorical',
                                                 shuffle=True)
model.compile(optimizer='Adam',loss='categorical_crossentropy',metrics=['accuracy'])
step_size_train=train_generator.n//train_generator.batch_size
filepath=r'ckpt\Epochs_{epoch:02d}_Accuracy_{acc}_Loss_{loss}.h5'
checkpoint = ModelCheckpoint(filepath, monitor='val_loss', verbose=1,mode='max',period=period)
model.fit_generator(generator=train_generator,steps_per_epoch=1,epochs=epochs,callbacks=[checkpoint])
model.save_weights('model/final_weights.h5')
model_json = model.to_json()
with open("architecture\model_architecture.json", "w") as json_file:
    json_file.write(model_json)
t = train_generator.class_indices
res = dict((v,k) for k,v in t.items())
labels=pd.DataFrame.from_dict(res,columns=['classes'],orient='index')
labels.to_csv('labels.csv',index=False)

